<nav style="background: #20232a; padding: 15px;">
    <a href="carrito.php" style="color: white; margin-right: 20px;">🛒 Carrito</a>
    <a href="pedidos_pendientes.php" style="color: white; margin-right: 20px;">💳 Pendientes</a>
    <a href="pedidos_enviados.php" style="color: white; margin-right: 20px;">📦 Envíos</a>
    <a href="historial.php" style="color: white; margin-right: 20px;">🕘 Historial</a>
    <a href="perfil.php" style="color: white; margin-right: 20px;">👤 Perfil</a>
    <a href="../backend/logout.php" style="color: #ff6b6b;">🚪 Salir</a>
</nav>
