<?php
include '../backend/conexion.php';
session_start();

if (!isset($_SESSION['id_usuario'])) {
    header("Location: ../login.html");
    exit();
}

$id_usuario = $_SESSION['id_usuario'];

// Obtener id_cliente desde id_usuario
$sql_cliente = "SELECT id_cliente FROM cliente WHERE id_usuario = ?";
$stmt_cliente = $conn->prepare($sql_cliente);
$stmt_cliente->bind_param("i", $id_usuario);
$stmt_cliente->execute();
$result_cliente = $stmt_cliente->get_result();

if ($result_cliente->num_rows === 0) {
    echo "No se encontró el cliente.";
    exit();
}

$id_cliente = $result_cliente->fetch_assoc()['id_cliente'];

// Obtener pedidos en estado "PendientePago"
$sql = "SELECT d.id_detalle, a.nombre AS nombre_articulo, a.precio, d.cantidad, 
               (a.precio * d.cantidad) AS total, d.direccion_envio, d.metodo_pago, 
               ta.nombre AS tipo_nombre, ta.icono
        FROM detalle_orden d
        JOIN articulo a ON d.id_articulo = a.id_articulo
        JOIN tipo_articulo ta ON a.id_tipo = ta.id_tipo
        JOIN orden o ON o.id_orden = d.id_orden
        WHERE o.estado = 'PendientePago' AND o.id_cliente = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_cliente);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Pedidos Pendientes de Pago</title>
    <link rel="stylesheet" href="../css/estilos.css">
    <style>
        .contenedor {
            max-width: 800px;
            margin: auto;
            padding: 20px;
        }

        .item-pedido {
            display: flex;
            align-items: center;
            border-bottom: 1px solid #ccc;
            padding: 15px 0;
        }

        .icono img {
            width: 80px;
            height: 80px;
        }

        .info {
            margin-left: 20px;
            flex-grow: 1;
        }

        .info h3 {
            margin: 0;
            font-size: 18px;
        }

        .info p {
            margin: 5px 0;
        }

        .editar-direccion {
            margin-top: 10px;
        }

        input[type="text"] {
            padding: 5px;
            width: 100%;
            max-width: 300px;
        }

        button {
            background-color: #007185;
            color: white;
            border: none;
            padding: 6px 12px;
            cursor: pointer;
            margin-top: 5px;
        }

        button:hover {
            background-color: #005f6b;
        }

        a {
            text-decoration: none;
            color: #007185;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<?php include 'navbar.php'; ?>

<div class="contenedor">
    <h2>Pedidos Pendientes de Pago</h2>

    <?php if ($result->num_rows > 0): ?>
        <?php while ($row = $result->fetch_assoc()): ?>
            <div class="item-pedido">
                <div class="icono">
                    <img src="../img/categorias/<?= htmlspecialchars($row['icono']); ?>" alt="<?= htmlspecialchars($row['tipo_nombre']); ?>">
                </div>
                <div class="info">
                    <h3><?= htmlspecialchars($row['nombre_articulo']); ?></h3>
                    <p>Cantidad: <?= $row['cantidad']; ?></p>
                    <p>Total: $<?= number_format($row['total'], 2); ?></p>
                    <p>Método de pago: <?= htmlspecialchars($row['metodo_pago']); ?></p>

                    <form action="../backend/actualizar_direccion.php" method="POST" class="editar-direccion">
                        <input type="hidden" name="id_detalle" value="<?= $row['id_detalle']; ?>">
                        <label for="direccion">Dirección de envío:</label><br>
                        <input type="text" name="direccion_envio" value="<?= htmlspecialchars($row['direccion_envio']); ?>" required>
                        <br><button type="submit">Actualizar dirección</button>
                    </form>
                </div>
            </div>
        <?php endwhile; ?>
    <?php else: ?>
        <p style="text-align:center;">No tienes pedidos pendientes de pago.</p>
    <?php endif; ?>
</div>

</body>
</html>
