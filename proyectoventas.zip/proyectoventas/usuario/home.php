<?php
session_start();
if (!isset($_SESSION['id_cliente'])) {
    header("Location: ../login.html");
    exit;
}

$usuario = $_SESSION['nombre_usuario'];
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Inicio - RC</title>
    <link rel="stylesheet" href="../css/estilos.css">
    <style>
        .opciones {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 30px;
            margin-top: 80px;
        }

        .opcion {
            padding: 30px;
            background-color: #fff;
            border-radius: 12px;
            box-shadow: 0 0 10px rgba(0,0,0,0.2);
            text-align: center;
            width: 200px;
            font-size: 18px;
        }

        .opcion a {
            text-decoration: none;
            color: #20232a;
            display: block;
        }

        .opcion:hover {
            background-color: #f0f0f0;
        }

        .saludo {
            text-align: center;
            margin-top: 50px;
        }
    </style>
</head>
<body>
    <div class="saludo">
        <h1>Bienvenido, <?= htmlspecialchars($usuario) ?> 👋</h1>
        <p>¿Qué deseas hacer hoy?</p>
    </div>

    <div class="opciones">
        <div class="opcion"><a href="carrito.php">🛒 Carrito</a></div>
        <div class="opcion"><a href="pedidos_pendientes.php">💳 Pendientes de Pago</a></div>
        <div class="opcion"><a href="pedidos_enviados.php">📦 Pedidos Envío</a></div>
        <div class="opcion"><a href="historial.php">🕘 Historial</a></div>
        <div class="opcion"><a href="perfil.php">👤 Mi Perfil</a></div>
    </div>
</body>
</html>
