<?php
include '../backend/conexion.php';
session_start();

if (!isset($_SESSION['id_usuario'])) {
    header("Location: ../login.html");
    exit();
}

$id_usuario = $_SESSION['id_usuario'];

// Obtener id_cliente desde id_usuario
$sql_cliente = "SELECT id_cliente FROM cliente WHERE id_usuario = ?";
$stmt_cliente = $conn->prepare($sql_cliente);
$stmt_cliente->bind_param("i", $id_usuario);
$stmt_cliente->execute();
$result_cliente = $stmt_cliente->get_result();

if ($result_cliente->num_rows === 0) {
    echo "No se encontró el cliente.";
    exit();
}

$id_cliente = $result_cliente->fetch_assoc()['id_cliente'];

// Obtener productos en estado 'Registrado' (carrito)
$sql = "SELECT d.id_detalle, a.nombre AS nombre_articulo, a.precio, d.cantidad,
               (a.precio * d.cantidad) AS total, ta.nombre AS tipo_nombre, ta.icono
        FROM detalle_orden d
        JOIN articulo a ON d.id_articulo = a.id_articulo
        JOIN tipo_articulo ta ON a.id_tipo = ta.id_tipo
        JOIN orden o ON o.id_orden = d.id_orden
        WHERE o.estado = 'Registrado' AND o.id_cliente = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_cliente);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Carrito de Compras</title>
    <link rel="stylesheet" href="../css/estilos.css">
    <style>
        .carrito-container {
            display: flex;
            flex-direction: column;
            padding: 20px;
            max-width: 800px;
            margin: auto;
        }

        .item-carrito {
            display: flex;
            align-items: center;
            padding: 15px;
            border-bottom: 1px solid #ccc;
            position: relative;
        }

        .eliminar {
            margin-right: 15px;
        }

        .eliminar form {
            display: inline;
        }

        .eliminar button {
            background: none;
            border: none;
            font-size: 18px;
            cursor: pointer;
            color: red;
        }

        .icono img {
            width: 80px;
            height: 80px;
            object-fit: contain;
        }

        .info {
            margin-left: 20px;
        }

        .info h3 {
            margin: 0;
            font-size: 18px;
        }

        .info p {
            margin: 5px 0;
        }

        a {
            text-decoration: none;
            color: #007185;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<?php include 'navbar.php'; ?>

<h2 style="text-align:center;">Carrito de Compras</h2>

<div class="carrito-container">
    <?php if ($result->num_rows > 0): ?>
        <?php while ($row = $result->fetch_assoc()): ?>
            <div class="item-carrito">
                <div class="eliminar">
                    <form action="../backend/borrar_producto.php" method="POST">
                        <input type="hidden" name="id_detalle" value="<?= $row['id_detalle']; ?>">
                        <button type="submit" title="Eliminar">🗑️</button>
                    </form>
                </div>
                <div class="icono">
                    <a href="detalle_compra.php?id_detalle=<?= $row['id_detalle']; ?>">
                        <img src="../img/categorias/<?= htmlspecialchars($row['icono']); ?>" alt="<?= htmlspecialchars($row['tipo_nombre']); ?>">
                    </a>
                </div>
                <div class="info">
                    <a href="detalle_compra.php?id_detalle=<?= $row['id_detalle']; ?>">
                        <h3><?= htmlspecialchars($row['nombre_articulo']); ?></h3>
                    </a>
                    <p>Cantidad: <?= $row['cantidad']; ?></p>
                    <p>Total: $<?= number_format($row['total'], 2); ?></p>
                </div>
            </div>
        <?php endwhile; ?>
    <?php else: ?>
        <p style="text-align:center;">Tu carrito está vacío.</p>
    <?php endif; ?>
</div>

</body>
</html>
