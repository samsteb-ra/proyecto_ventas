<?php
require 'conexion.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre_usuario = $_POST['nombre_usuario'];
    $contrasena = password_hash($_POST['contrasena'], PASSWORD_BCRYPT);
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $correo = $_POST['correo'];
    $telefono = $_POST['telefono'];

    try {
        // 1. Insertar usuario
        $stmt = $conn->prepare("INSERT INTO usuario (nombre_usuario, contrasena) VALUES (?, ?) RETURNING id_usuario");
        $stmt->execute([$nombre_usuario, $contrasena]);
        $id_usuario = $stmt->fetchColumn();

        // 2. Insertar cliente asociado
        $stmt = $conn->prepare("INSERT INTO cliente (nombre, apellido, correo, telefono, id_usuario) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$nombre, $apellido, $correo, $telefono, $id_usuario]);

        header("Location: ../login.html?registro=exitoso");
        exit;
    } catch (PDOException $e) {
        echo "Error al registrar: " . $e->getMessage();
    }
}
?>
