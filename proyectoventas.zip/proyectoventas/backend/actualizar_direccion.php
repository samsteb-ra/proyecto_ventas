<?php
session_start();
require 'conexion.php';

if (!isset($_SESSION['id_usuario'])) {
    header("Location: ../login.html");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_detalle = $_POST['id_detalle'] ?? null;
    $direccion = trim($_POST['direccion_envio'] ?? '');

    if (!$id_detalle || empty($direccion)) {
        echo "Datos incompletos.";
        exit();
    }

    // Verificar que el detalle pertenece al usuario y está en estado PendientePago
    $sql = "SELECT d.id_detalle
            FROM detalle_orden d
            JOIN orden o ON d.id_orden = o.id_orden
            JOIN cliente c ON o.id_cliente = c.id_cliente
            WHERE d.id_detalle = ? AND o.estado = 'PendientePago' AND c.id_usuario = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $id_detalle, $_SESSION['id_usuario']);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        echo "No se encontró el pedido o no tienes permiso.";
        exit();
    }

    // Actualizar dirección
    $update = "UPDATE detalle_orden SET direccion_envio = ? WHERE id_detalle = ?";
    $stmt_update = $conn->prepare($update);
    $stmt_update->bind_param("si", $direccion, $id_detalle);

    if ($stmt_update->execute()) {
        header("Location: ../usuario/pedidos_pendientes.php");
        exit();
    } else {
        echo "Error al actualizar la dirección.";
    }
} else {
    echo "Acceso denegado.";
}
?>
