<?php
session_start();
if (!isset($_SESSION['id_cliente'])) {
    header("Location: ../login.html");
    exit;
}

require 'conexion.php';

if (isset($_POST['id_detalle_orden'])) {
    $id = $_POST['id_detalle_orden'];
    $stmt = $conn->prepare("DELETE FROM detalle_orden WHERE id_detalle_orden = :id");
    $stmt->execute(['id' => $id]);
}

header("Location: ../usuario/carrito.php");
exit;
