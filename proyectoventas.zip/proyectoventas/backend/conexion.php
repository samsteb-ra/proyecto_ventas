<?php
$host = "localhost";
$dbname = "proyecto_ventas";
$user = "postgres";
$password = "postgres";  // Reemplaza por tu clave

try {
    $conn = new PDO("pgsql:host=$host;dbname=$dbname", $user, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error de conexión: " . $e->getMessage());
}
?>
