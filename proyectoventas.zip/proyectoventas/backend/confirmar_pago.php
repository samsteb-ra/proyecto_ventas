<?php
session_start();
require 'conexion.php';

if (!isset($_SESSION['id_usuario'])) {
    header("/home/sam/proyectoventas/login.html");
    exit;
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_cliente = $_SESSION['id_cliente'];
    $direccion_envio = trim($_POST['direccion']);
    $metodo_pago = $_POST['metodo_pago'];
    $id_detalle_orden = $_POST['id_detalle_orden'];

    try {
        // 1. Verificar que el detalle de orden pertenece al cliente
        $stmt = $conn->prepare("
            SELECT do.id_detalle_orden
            FROM detalle_orden do
            JOIN orden_compra oc ON do.id_orden = oc.id_orden
            WHERE do.id_detalle_orden = :id_detalle AND oc.id_cliente = :id_cliente
        ");
        $stmt->execute([
            'id_detalle' => $id_detalle_orden,
            'id_cliente' => $id_cliente
        ]);

        if ($stmt->rowCount() === 0) {
            die("No tienes permiso para modificar esta orden.");
        }

        // 2. Actualizar dirección y método de pago
        $stmt = $conn->prepare("
            UPDATE detalle_orden
            SET direccion_envio = :direccion, metodo_pago = :metodo, estado = 'pendiente_pago'
            WHERE id_detalle_orden = :id_detalle
        ");
        $stmt->execute([
            'direccion' => $direccion_envio,
            'metodo' => $metodo_pago,
            'id_detalle' => $id_detalle_orden
        ]);

        header("Location: ../usuario/pedidos_pendientes.html?ok=1");
        exit;

    } catch (PDOException $e) {
        echo "Error al confirmar el pago: " . $e->getMessage();
    }
}
?>
