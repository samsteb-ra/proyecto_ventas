<?php
require 'conexion.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario_input = $_POST['usuario'];
    $contrasena_input = $_POST['contrasena'];

    try {
        // Buscar por nombre_usuario o correo
        $stmt = $conn->prepare("
            SELECT u.id_usuario, u.nombre_usuario, u.contrasena, c.id_cliente 
            FROM usuario u 
            JOIN cliente c ON c.id_usuario = u.id_usuario
            WHERE u.nombre_usuario = :input OR c.correo = :input
        ");
        $stmt->execute(['input' => $usuario_input]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($contrasena_input, $user['contrasena'])) {
            $_SESSION['id_usuario'] = $user['id_usuario'];
            $_SESSION['id_cliente'] = $user['id_cliente'];
            $_SESSION['nombre_usuario'] = $user['nombre_usuario'];

            header("Location: ../usuario/home.php");
            exit;
        } else {
            header("Location: ../login.html?error=1");
            exit;
        }
    } catch (PDOException $e) {
        echo "Error de login: " . $e->getMessage();
    }
}
?>
